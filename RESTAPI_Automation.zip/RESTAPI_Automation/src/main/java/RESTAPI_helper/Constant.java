package RESTAPI_helper;

public interface Constant {
	public String PATH=System.getProperty("user.dir")+"/resources/";
}
